import org.junit.platform.launcher.Launcher;
import org.junit.platform.launcher.LauncherDiscoveryRequest;
import org.junit.platform.launcher.core.LauncherDiscoveryRequestBuilder;
import org.junit.platform.launcher.core.LauncherFactory;
import org.junit.platform.engine.discovery.DiscoverySelectors;
import org.junit.platform.engine.discovery.PackageNameFilter;
import org.junit.platform.launcher.listeners.SummaryGeneratingListener;
import org.junit.platform.launcher.listeners.TestExecutionSummary;

public class LibreriaJava {
    public static void main(String[] args) {
        SummaryGeneratingListener listener = new SummaryGeneratingListener();
   

        // Richiesta di discovery per tutti i test nel pacchetto 'zaptest' (ricorsivo)
        LauncherDiscoveryRequest request = LauncherDiscoveryRequestBuilder.request()
                .selectors(
                    DiscoverySelectors.selectPackage("zapsdtest")
                )
                .filters(
                    PackageNameFilter.includePackageNames("zapsdtest")
                )
                .build();

        Launcher launcher = LauncherFactory.create();
        launcher.registerTestExecutionListeners(listener);
        launcher.execute(request);

        // Stampa dei risultati sul terminale
          TestExecutionSummary summary = listener.getSummary();

        System.out.println("===== Riepilogo test =====");
        System.out.println("Totale test eseguiti: " + summary.getTestsFoundCount());
        System.out.println("Test riusciti: " + summary.getTestsSucceededCount());
        System.out.println("Test falliti: " + summary.getTestsFailedCount());
        System.out.println("Test saltati: " + summary.getTestsSkippedCount());
        System.out.println("==========================");


        if(summary.getTotalFailureCount() > 0){
            System.out.println("Ci sono fallimenti!");
            summary.getFailures().forEach(failure -> {
                System.out.println("Test fallito: " + failure.getTestIdentifier().getDisplayName());
                System.out.println("Eccezione: " + failure.getException());
            });
        }
    }
}
